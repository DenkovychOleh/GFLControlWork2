-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Дек 28 2022 г., 19:25
-- Версия сервера: 10.4.27-MariaDB
-- Версия PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `taxi`
--

-- --------------------------------------------------------

--
-- Структура таблицы `car`
--

CREATE TABLE `car` (
  `id` int(11) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `year` int(11) NOT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `fuel_id` int(11) NOT NULL,
  `type_car_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `car`
--

INSERT INTO `car` (`id`, `brand`, `model`, `year`, `driver_id`, `fuel_id`, `type_car_id`) VALUES
(2, 'Volkswagen', 'Passat CC', 2013, 1, 1, 1),
(7, 'Honda', 'Civic', 2018, 3, 3, 1),
(8, 'Volkswagen', 'Touran', 2012, 2, 1, 2),
(9, 'Mercedes', 'Vito', 2012, 4, 2, 3),
(10, 'Nissan', 'Leaf', 2012, 5, 4, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `client`
--

INSERT INTO `client` (`id`, `first_name`, `last_name`, `phone`) VALUES
(2, 'Zinchenko', 'Oleksandr ', '0989988999'),
(3, 'Shevchenko', 'Andriy', '0667788999'),
(4, 'Pyatov', 'Andriy', '0971122333'),
(5, 'Malinovskyi', 'Ruslan', '0978877111'),
(6, 'Yarmolenko', 'Andriy', '0966666611'),
(11, 'g', 'eqweqwgfd', 'gd8989'),
(16, 't', 'etr', 'ter');

-- --------------------------------------------------------

--
-- Структура таблицы `driver`
--

CREATE TABLE `driver` (
  `id` int(11) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `experience` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `tariff` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `driver`
--

INSERT INTO `driver` (`id`, `age`, `experience`, `first_name`, `last_name`, `phone`, `tariff`) VALUES
(1, 21, 2, 'Dolyk', 'Andriy', '0687788777', 5),
(2, 20, 1, 'Vyshnevskiy', 'Yuriy', '0671112222', 4.5),
(3, 24, 3, 'Dashko', 'Sergey', '0989983434', 4.5),
(4, 38, 12, 'Kravets', 'Nazar', '0680001112', 4),
(5, 21, 2, 'Tsytsa', 'Sergey', '0984433444', 3.5);

-- --------------------------------------------------------

--
-- Структура таблицы `driver_car`
--

CREATE TABLE `driver_car` (
  `car_id` int(11) DEFAULT NULL,
  `driver_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `driver_car`
--

INSERT INTO `driver_car` (`car_id`, `driver_id`) VALUES
(2, 1),
(7, 3),
(8, 2),
(9, 4),
(10, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `fuel`
--

CREATE TABLE `fuel` (
  `id` int(11) NOT NULL,
  `fuel` varchar(30) DEFAULT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `fuel`
--

INSERT INTO `fuel` (`id`, `fuel`, `price`) VALUES
(1, 'Gasoline', 54),
(2, 'Diesel', 56),
(3, 'Hybrid', 54),
(4, 'Electric', 4.5);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `average consumption` double DEFAULT NULL,
  `date` datetime(6) NOT NULL,
  `distance` double NOT NULL,
  `finish_address` varchar(50) NOT NULL,
  `passengers` int(11) NOT NULL,
  `start_address` varchar(50) NOT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `client_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `average consumption`, `date`, `distance`, `finish_address`, `passengers`, `start_address`, `driver_id`, `client_id`) VALUES
(1, 8.5, '2022-12-16 17:31:34.000000', 8.1, 'Rynok,3', 2, 'Lisova,5', 5, 2),
(2, 7.1, '2022-11-23 17:32:14.000000', 12.5, 'Ukrainian,19', 3, 'Shevchenka,10', 3, 5),
(3, 12.4, '2022-11-25 17:32:20.000000', 5.2, 'Ivashka,14', 1, 'Nova,12', 2, 2),
(4, 7.4, '2022-11-28 17:32:24.000000', 3.2, 'Boguna,2', 1, 'Rynok,1', 1, 3),
(5, 8.5, '2022-12-10 17:32:33.000000', 8.2, 'Shevchenka,5', 6, 'Khmelnytskogo,12', 2, 4),
(6, 9.1, '2022-12-18 17:32:37.000000', 6.2, 'Vesnyana,3', 4, 'Sahaidachnoho,8', 1, 2),
(7, 11.2, '2022-11-22 17:32:42.000000', 8.7, 'Lisova,8', 7, 'Vesnyana,5', 4, 3),
(8, 10, '2022-12-11 17:32:48.000000', 2.1, 'Ivasyka,4', 2, 'Rynok,11', 5, 6);

-- --------------------------------------------------------

--
-- Структура таблицы `type_car`
--

CREATE TABLE `type_car` (
  `id` int(11) NOT NULL,
  `fuel_capacity` int(11) DEFAULT NULL,
  `passengers_seats` int(11) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `type_car`
--

INSERT INTO `type_car` (`id`, `fuel_capacity`, `passengers_seats`, `type`) VALUES
(1, 50, 4, 'Sedan'),
(2, 70, 6, 'Minivan'),
(3, 90, 8, 'Van');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKt075681k23ii3uvdxjvvmmpm` (`driver_id`),
  ADD KEY `FK7rhbua2q4v02et0jfpe7y76bh` (`fuel_id`),
  ADD KEY `FKhn48vu110r5warpb7vq1rkotj` (`type_car_id`);

--
-- Индексы таблицы `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `driver_car`
--
ALTER TABLE `driver_car`
  ADD PRIMARY KEY (`driver_id`),
  ADD KEY `FKkp4qais5j25vo6sbl9iwtlq4q` (`car_id`);

--
-- Индексы таблицы `fuel`
--
ALTER TABLE `fuel`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKlfsgolihtmfujlg0egc76sh8w` (`driver_id`),
  ADD KEY `FK17yo6gry2nuwg2erwhbaxqbs9` (`client_id`);

--
-- Индексы таблицы `type_car`
--
ALTER TABLE `type_car`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `car`
--
ALTER TABLE `car`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `driver`
--
ALTER TABLE `driver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `fuel`
--
ALTER TABLE `fuel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `type_car`
--
ALTER TABLE `type_car`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `car`
--
ALTER TABLE `car`
  ADD CONSTRAINT `FK7rhbua2q4v02et0jfpe7y76bh` FOREIGN KEY (`fuel_id`) REFERENCES `fuel` (`id`),
  ADD CONSTRAINT `FKhn48vu110r5warpb7vq1rkotj` FOREIGN KEY (`type_car_id`) REFERENCES `type_car` (`id`),
  ADD CONSTRAINT `FKt075681k23ii3uvdxjvvmmpm` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`id`);

--
-- Ограничения внешнего ключа таблицы `driver_car`
--
ALTER TABLE `driver_car`
  ADD CONSTRAINT `FKaksd0t6ur8arifj8b9ud6uvcq` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`id`),
  ADD CONSTRAINT `FKkp4qais5j25vo6sbl9iwtlq4q` FOREIGN KEY (`car_id`) REFERENCES `car` (`id`);

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `FK17yo6gry2nuwg2erwhbaxqbs9` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`),
  ADD CONSTRAINT `FKlfsgolihtmfujlg0egc76sh8w` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
